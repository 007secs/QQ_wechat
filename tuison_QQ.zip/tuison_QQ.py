import time
from lxml import etree
from selenium import webdriver
from pymouse import PyMouse
import pyautogui
import pyperclip
import schedule
#import func_timeout

headers = {
    'If-None-Match': '616d5f72-850',
    'Referer': 'https://pos.baidu.com/',
    'sec-ch-ua': '"Not A;Brand";v="99", "Chromium";v="101", "Google Chrome";v="101"',
    'sec-ch-ua-mobile': '?0',
    'sec-ch-ua-platform': '"Windows"',
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/101.0.4951.67 Safari/537.36'
}

option = webdriver.ChromeOptions()
option.add_argument("--disable-blink-features=AutomationControlled")  # 反扒
option.add_argument('--headless')  # 增加一个参数即可实现在不打开浏览器的情况下完成系列操作
#option.add_argument('-kiosk') #全屏浏览器
option.add_argument("user-agent='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/95.0.4638.69 Safari/537.36'")
'''
def biying():
    driver = webdriver.Chrome(options=option)
    url="https://cn.bing.com/search?q=%E8%AD%A6%E5%AF%9F%E6%96%B0%E9%97%BB"
    driver.get(url)
    time.sleep(2)
    response = driver.page_source
    res = etree.HTML(response)
    title = res.xpath('//*[@id="ns_cal_big_title"]/text()[1]')
    title_1 = res.xpath('//*[@id="ns_cal_big_title"]/text()[2]')
    lianjie = res.xpath('//a[@class="itm_cap_link"]/@href')
    for i in range(3):
        title_new = title[i]
        title_1_new = title_1[i]
        lianjie_new = lianjie[i]
        result = title_new+"警察"+title_1_new
        file_handle = open('result.txt', mode='w')
        file_handle.write(result+'\n'+lianjie_new+'\n')
    driver.close()
'''
def t00ls():
    txt = "t00ls安全:"
    file_handle = open('result.txt', mode='a', encoding='utf-8')
    file_handle.write(txt+'\n')
    file_handle.close()
    driver = webdriver.Chrome(options=option)
    url = "https://www.t00ls.com/news.html"
    driver.get(url)
    time.sleep(3)
    response = driver.page_source
    res = etree.HTML(response)
    #当前时间
    data_time = time.strftime('%Y-%m-%d', time.localtime())
    time_local = time.strftime('%Y-%m-%d %H:%M:%S', time.localtime())
    #print(data_time)
    data = res.xpath('//*[contains(@id,"articles-")]/div/div[2]/div/span[1]/span/@title')
    for i in range(1):
        news_data = data[i]
        data_new = list(news_data[:10])
        data_new.insert(5,"0")
        data_new_0 = ''.join(data_new)
     #   print(data_time)
     #   print(data_new_0)
        #判断是不是进日的消息咨询

            #是今日的新闻 则获取该新闻的title和链接
        title = res.xpath('//*[contains(@id,"articles-")]/div/div[2]/h4/a/text()')
        lianjie = res.xpath('//*[contains(@id,"articles-")]/div/div[2]/h4/a/@href')
        for i in range(1):
            title_t00ls = str(title[i])
            t00ls_new = "标题:"+title_t00ls + "\n" + "地址:" +"https://www.t00ls.com/" + str(lianjie[i])
            file_handle = open('result.txt', mode='a', encoding='utf-8')
            file_handle.write(t00ls_new+ '\n')
            file_handle.close()
        '''    
        else:
            a = "截至目前时间:"+time_local+"暂无安全咨询"
            file_handle = open('result.txt', mode='a', encoding='utf-8')
            file_handle.write(a + '\n')
            file_handle.close()
        '''
    driver.close()

def souhu():
    txt = "警法焦点:"
    file_handle = open('result.txt', mode='a', encoding='utf-8')
    file_handle.write(txt+ '\n')
    file_handle.close()
    driver = webdriver.Chrome(options=option)
    url = "https://www.sohu.com/xchannel/tag?key=%E8%AD%A6%E6%B3%95"
    driver.get(url)
    time.sleep(1)
    response = driver.page_source
    res = etree.HTML(response)
    time.sleep(1)
    title = res.xpath("//div[@class='title']/text()")
    lianjie = res.xpath('//a[@target="_blank" and @class="item"]/@href')
    for i in range(4):
        souhu_news ="标题:"+ title[i]+"\n"+"地址:"+'https:'+lianjie[i]
        result = souhu_news
        file_handle = open('result.txt', mode='a',encoding='utf-8')
        file_handle.write(result + '\n')
        file_handle.close()
    driver.close()

def yijing():
    txt = "蚁景网安&&合天网安:"
    file_handle = open('result.txt', mode='a', encoding='utf-8')
    file_handle.write(txt + '\n')
    file_handle.close()
    driver = webdriver.Chrome(options=option)
    url = "https://www.yijinglab.com/industry"
    driver.get(url)
    time.sleep(1)
    response = driver.page_source
    res = etree.HTML(response)
    time.sleep(1)
    data_time = time.strftime('%Y-%m-%d', time.localtime())
    yijing_time = res.xpath('//span[@class="timer"]/text()')
    title = "网络安全日报"+" "+data_time
    lianjie = res.xpath('//a[@target="_blank"]/@href')
    for i in range(1):
        lianjie_yijing = lianjie[i]
        yijing_time_news = yijing_time[i]
        data_new_yijing = list(yijing_time_news[:10])
        data_new_1 = ''.join(data_new_yijing)
   #     print(data_new_1)
        if data_new_1 == data_time:
            result ="标题:" + title+"\n"+"地址:"+"https://www.yijinglab.com"+lianjie_yijing
            file_handle = open('result.txt', mode='a', encoding='utf-8')
            file_handle.write(result + '\n')
            file_handle.close()
        else:
            a = "截至目前时间:"+data_time+"暂无安全咨询"
            file_handle = open('result.txt', mode='a', encoding='utf-8')
            file_handle.write(a + '\n')
            file_handle.close()
    driver.close()

def qq_ceshi():
    m = PyMouse()  # 初始化鼠标
    m.move(65,140)  # 移动到指定位置
    m.click(65,140, 1, 2)  # 鼠标点击
    '''
    pyautogui.press('G')
    '''
    nam = 1790009194
    pyautogui.typewrite(str(nam))
    time.sleep(1)
    m = PyMouse()
    m.move(49, 240)  # 移动到指定位置
    m.click(49, 240, 1, 2)
    f = open("result.txt", 'r',encoding='utf-8')
    byt = f.read()
    pyperclip.copy(byt)
    pyautogui.hotkey('ctrl', 'v', interval=0.15)
    pyautogui.hotkey('ctrl', 'enter', interval=0.15)

def qq():
    m = PyMouse()  # 初始化鼠标
    m.move(65,140)  # 移动到指定位置
    m.click(65,140, 1, 2)  # 鼠标点击
    nam = 469781792
    pyautogui.typewrite(str(nam))
    time.sleep(1)
    m = PyMouse()
    m.move(49, 240)  # 移动到指定位置
    m.click(49, 240, 1, 2)
    f = open("result.txt", 'r',encoding='utf-8')
    byt = f.read()
    pyperclip.copy(byt)
    pyautogui.hotkey('ctrl', 'v', interval=0.15)
    pyautogui.hotkey('ctrl', 'enter', interval=0.15)

def xieru():
    txt_start = "# 焦点推送：" + "\n" + "==================="
    file_handle = open('result.txt', mode='a', encoding='utf-8')
    file_handle.write(txt_start + '\n')
    file_handle.close()

def empty():
    file = open("result.txt", 'w').close()

def start_ceshi():
    empty() #清空前一日的推送
    xieru() #加个署名
    souhu() #搜狐警法推送
    t00ls() #t00ls新闻推送
    yijing() #蚁景&&合天推送
    qq_ceshi()  #qq发送

def start():
    qq()  #qq发送

schedule.every().day.at("11:00").do(start_ceshi)    #注意 这个地方不能带括号
schedule.every().day.at("13:00").do(start)
while True:
    schedule.run_pending()
    time.sleep(1)

'''
if __name__ == '__main__':
    start_ceshi()
'''